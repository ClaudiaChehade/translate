#!/bin/bash

cur_persist_file="persist.txt"
yaml_file="update_yaml_xxtrinsic.yaml"
export LD_LIBRARY_PATH=$LD_LIBRARY_PATH:/opt/vrte/lib/:/opt/app/:/usr/local/lib3rd/usr/lib/:/asw/lib_w3/perception/
# 先写一份进去
/opt/app/variantServer/bin/xcalib_cli -w `pwd`/old_param/
# 根据另一组 yaml 来更新
new_data_path="`pwd`/new_param/"
echo $new_data_path
sed -ri "s!data_path.*!data_path: \"${new_data_path}\"!g" $yaml_file
# TODO：调用接口

# 读取更新后的 persist 中的参数
/opt/app/variantServer/bin/xcalib_cli -r > $cur_persist_file

# 对结果进行校验
./auto_check_result $yaml_file $cur_persist_file