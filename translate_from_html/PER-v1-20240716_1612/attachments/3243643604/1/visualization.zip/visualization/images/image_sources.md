https://brandguide.bosch.com (not accessible with firefox :-( )
* question-frame.svg