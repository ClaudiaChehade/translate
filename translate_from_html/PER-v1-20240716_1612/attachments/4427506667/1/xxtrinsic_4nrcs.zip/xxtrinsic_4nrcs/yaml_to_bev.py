import os
import re
import cv2
import yaml
import argparse
import numpy as np
 
 
def check_files_exist(yaml_path):
    is_all_exist = True
    for file_name in ['nrcs_front.yaml', 'nrcs_right.yaml', 'nrcs_rear.yaml', 'nrcs_left.yaml']:
        file_path = os.path.join(yaml_path, file_name)
        if os.path.exists(file_path) is False:
            is_all_exist = False
    return is_all_exist
 
 
def rename_files(yaml_path):
    pattern = re.compile(r'.*_nrcs_*_yaml_.*\.log$')   
    files_rename = []
    for root, _, files in os.walk(yaml_path):
        for file in files:
            if pattern.match(file):
                old_file_path = os.path.join(root, file)
                new_file_path = os.path.join(root, 'nrcs_front.yaml')
                try:
                    os.rename(old_file_path, new_file_path)
                    files_rename.append(new_file_path)
                    print(f'rename: {old_file_path} -> {new_file_path}')
                except Exception as e:
                    print(f'[ERROR] rename {old_file_path} to {new_file_path}: {e}')
    return files_rename
 
 
def generate_extrinsics_txt(yaml_path):
    first_flag = True
    for camera in ["front", "right", "rear", "left"]:
        file = os.path.join(yaml_path, f'nrcs_{camera}.yaml')
        fs = cv2.FileStorage(file, cv2.FILE_STORAGE_READ)
        if not fs.isOpened():
            print(f"can not open {file}")
            exit(0)
        initial_extrinsic = fs.getNode("T_v_c").mat()
        if initial_extrinsic is None:
            print("lack extrinsic")
            exit(0)
        T_v_c = np.array(initial_extrinsic, dtype=np.float64)
        filename = os.path.join(yaml_path, 'extrinsics.txt')
        if first_flag:
            with open(filename, 'w') as outfile:
                outfile.write("CAM_NUM: 4\n")
        else:
            with open(filename, 'a') as outfile:
                pass
        world1_T_world2 = np.array([[-1, 0, 0, 0],
                                    [0, -1, 0, 0],
                                    [0, 0, 1, 0],
                                    [0, 0, 0, 1]], dtype=np.float64)
        eigen_T_c_v = np.linalg.inv(T_v_c)
        cam_T_world1 = eigen_T_c_v
        cam_T_world2 = cam_T_world1 @ world1_T_world2
        cam_T_world2[0, 3] *= 1000.0
        cam_T_world2[1, 3] *= 1000.0
        cam_T_world2[2, 3] *= 1000.0
        world2_T_cam = np.linalg.inv(cam_T_world2)
        with open(filename, 'a') as outfile:
            np.savetxt(outfile, cam_T_world2, fmt='%.5f', delimiter=' ')
            np.savetxt(outfile, world2_T_cam, fmt='%.5f', delimiter=' ')
            first_flag = False
 
 
def generate_cam_txt(yaml_path):
    for index, camera in enumerate(["front", "right", "rear", "left"]):
        with open(os.path.join(yaml_path, f'nrcs_{camera}.yaml'), 'r') as file:
            lines = file.readlines()[2:]
            split_index = next((i for i, line in enumerate(lines) if line.startswith('T_v_c: !!opencv-matrix')), len(lines))
            data = yaml.safe_load(''.join(lines[:split_index]))
             
        image_width = data['image_width']
        image_height = data['image_height']
        poly_parameters = data['poly_parameters']
        ss = f"{poly_parameters['p0']} {poly_parameters['p1']} {poly_parameters['p2']} {poly_parameters['p3']} {poly_parameters['p4']}"
        inv_poly_parameters = data['inv_poly_parameters']
        ss_inv = " ".join(str(inv_poly_parameters[f'p{i}']) for i in range(14))
        affine_parameters = data['affine_parameters']
        cx = affine_parameters['cx']
        cy = affine_parameters['cy']
        c = affine_parameters['ac']
        d = affine_parameters['ad']
        e = affine_parameters['ae']
  
        with open(os.path.join(yaml_path, f'cam_{index}.txt'), 'w') as file:
            file.write("Model: Ocam\n\n")
            file.write(f"width: {image_width}\n")
            file.write(f"height: {image_height}\n\n")
            file.write(f"ss: {ss}\n")
            file.write(f"ss_inv: {ss_inv}\n\n")
            file.write(f"cx: {cx}\n")
            file.write(f"cy: {cy}\n\n")
            file.write(f"c: {c}\n")
            file.write(f"d: {d}\n")
            file.write(f"e: {e}\n")
  
 
def main():
    parser = argparse.ArgumentParser(description="generate bev by yaml")
    parser.add_argument('-y', '--yaml_path', required=True, type=str)
    args = parser.parse_args()
    yaml_path = args.yaml_path
 
    if check_files_exist(yaml_path) is False:
        rename_files(yaml_path)
    if check_files_exist(yaml_path) is True:
        print('all nrcs_*.yaml is exist, generate bev ...')
        generate_extrinsics_txt(yaml_path)
        generate_cam_txt(yaml_path)
    else:
        print('[ERROR] fail to generate bev without all nrcs_*.yaml')
 
 
if __name__ == '__main__':
    main()